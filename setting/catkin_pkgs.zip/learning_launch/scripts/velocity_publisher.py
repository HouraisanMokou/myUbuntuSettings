#!/usr/bin/env python
# -*- coding: utf-8\ -*-

import rospy
from geometry_msgs.msg import Twist

def velocity_pubisher():
    rospy.init_node('velocity_publisher',anonymous=True)
    turtle_vel_pub = rospy.Publisher('/turtle1/cmd_vel',Twist,queue_size=10)
    publish_frequency=rospy.get_param('~publish_frequency')
    rate=rospy.Rate(publish_frequency)

    while not rospy.is_shutdown():
        vel_msg = Twist()
        vel_msg.linear.x=rospy.get_param('~linear_x')
        vel_msg.angular.z=rospy.get_param('~group/angular_z')
        turtle_vel_pub.publish(vel_msg)
        rospy.loginfo("publish turtle velocity command[%0.2f m/s, %0.2f rad/s]",\
            vel_msg.linear.x,vel_msg.angular.z)
        
        rate.sleep()

if __name__=="__main__":
    try:
        velocity_pubisher()
    except rospy.ROSInterruptException:
        pass