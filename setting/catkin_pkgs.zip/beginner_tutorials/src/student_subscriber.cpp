#include "ros/ros.h"
#include "beginner_tutorials/Student.h"

void studentCallback(const beginner_tutorials::Student::ConstPtr & msg)
{
    ROS_INFO("Subcribe Student's score: name:%s id:%s grade:%d score:%.2f",
            msg->name.c_str(),msg->id.c_str(),msg->grade,msg->score);
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "listener");
    ros::NodeHandle n;
    ros::Subscriber person_info_sub = n.subscribe("/student_score", 1000, studentCallback);
    ros::spin();
    int count = 0;
    return 0;
}