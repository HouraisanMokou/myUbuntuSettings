#!/usr/bin/env python
# -*- coding: utf-8 -*-
import rospy
from beginner_tutorials.srv import *

def stringCallback(req):
    rospy.loginfo("the student id:%s",req.id)
    return StuScoreResponse("Jimmy","12345678",StuScoreResponse.junior,95.8)
def string_server():
    rospy.init_node('student_server')

    s=rospy.Service('/student_score',StuScore,stringCallback)

    print ("Ready to print hello string")
    rospy.spin()

if __name__=="__main__":
    string_server()