#!/usr/bin/env python
# -*- coding: utf-8 -*-
import rospy
from beginner_tutorials.srv import *

def string_client():
    rospy.init_node('student_client')
    rospy.wait_for_service('/student_score')
    try:
        string_client = rospy.ServiceProxy('/student_score',StuScore)
        response = string_client("12345678")
        return response
    except rospy.ServiceException as e:
        print("service call failed: %s"%e)

if __name__=="__main__":
    print("show the student's score:\n%s"%(string_client()))