#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
import rospy
from std_srvs.srv import SetBool, SetBoolRequest

def string_client():
    rospy.init_node('string_client')
    rospy.wait_for_service('print_string')
    try:
        string_client = rospy.ServiceProxy('print_string',SetBool)
        response = string_client(True)
        return response.success,response.message
    except rospy.ServiceException as e:
        print("service call failed: %s"%e)

if __name__=="__main__":
    print("Response : [%s] %s"%(string_client()))