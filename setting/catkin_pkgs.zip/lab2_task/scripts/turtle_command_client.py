#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
from tokenize import Double
import rospy
from lab2_task.srv import *
import argparse


def turtle_command_client(name, move, linear, angular):
    rospy.init_node('turtle_command_client')
    rospy.wait_for_service('turtle_command')
    try:
        client = rospy.ServiceProxy('turtle_command',turtle_command)
        response = client(name, move, linear, angular)
        return response
    except rospy.ServiceException as e:
        print("service call failed: %s"%e)

if __name__=="__main__":
    # parser=argparse.ArgumentParser("command_client")
    # parser.add_argument("--name",default="turtle1",type=str,help="the name of controlling turtle")
    # parser.add_argument("--move",default="True",type=str,help="the name of controlling turtle")
    # parser.add_argument("--linear",default=1.5,type=float,help="the linear speed of turtle")
    # parser.add_argument("--angular",default=1.2,type=float,help="the angular speed of turtle")

    # args,unkowwn=parser.parse_known_args()
    # bool_move=True if args.move.upper()=='TRUE' or args.move.upper()=='1' else False
    # # print("Response : %s"%(turtle_create_client('you')))
    # print("Response : %s"%(turtle_command_client(args.name,bool_move,args.linear,args.angular)))
    import sys
    bool_move=True if sys.argv[2]=="1" else False
    print("Response : %s"%(turtle_command_client(
        sys.argv[1],bool_move,float(sys.argv[3]),float(sys.argv[4]))))