#!/usr/bin/env python
# -*- coding: utf-8 -*-
from calendar import c
from cgitb import handler
from logging import handlers
from multiprocessing.connection import wait
from os import waitid_result
import random
from turtle import pos
from venv import create
from zipapp import create_archive
import rospy
from lab2_task.srv import *
from geometry_msgs.msg import Twist
from turtlesim.srv import Spawn,SpawnRequest
from turtlesim.msg import Pose

# def createCallback(req):
#     rospy.loginfo("the student id:%s",req.id)
#     return StuScoreResponse("Jimmy","12345678",StuScoreResponse.junior,95.8)
class Handler():
    def __init__(self,name='turtle1',vel=1.0,ang=2):
        self.name=name
        self.vel=vel
        self.ang=ang
        self.publisher=rospy.Publisher(f'/{name}/cmd_vel',Twist,queue_size=10)
        # rospy.wait_for_service(f'/{name}/pose')
        self.poses=rospy.Subscriber(f'/{name}/pose',Pose,poseCallBack)

def poseCallBack(msg):
    global poses
    poses.append((msg.x,msg.y))
def createCallback(req):
    global wait_list,handlers
    if req.name not in handlers.keys():
        wait_list.append(req.name)
        res=f"[{req.name}] creates successfully"
        rospy.loginfo(res)
        return turtle_createResponse(req.name,res)
    else:
        res=f"[{req.name}] already exists"
        rospy.loginfo(res)
        return turtle_createResponse(req.name,res)
def commandCallback(req):
    global command_wait_list,handlers
    command_wait_list.append((req.name,req.move,req.linear,req.angular))
    if req.name in handlers.keys():
        res=f"[{req.name}] add command successfully: "+\
             f"[move: {req.move}, linear: {req.linear}, angular: {req.angular}]"
        rospy.loginfo(res)
        return turtle_commandResponse(req.name,res)
    else:
        res=f"no such turtle [{req.name}]"
        rospy.loginfo(res)
        return turtle_commandResponse(req.name,res)
def turtle_command_server():
    rospy.init_node('turtle_command_server')

    publish_frequency=10
    rate=rospy.Rate(publish_frequency)

    global wait_list,handlers,create,command_wait_list
    handlers['turtle1']=Handler(vel=1.5,ang=1.2)
    create=rospy.ServiceProxy('/spawn',Spawn)
    create_reciever=rospy.Service('turtle_create',turtle_create,createCallback)
    command_reciever=rospy.Service('turtle_command',turtle_command,commandCallback)

    # req=SpawnRequest(0,0,0,name)
    
    while not rospy.is_shutdown():
        # for create
        for w in wait_list:
            if w not in handlers.keys():
                handlers[w]=Handler(name=w)
                x,y=random.random()*10,random.random()*10
                while (x,y) in poses:
                    x,y=random.random()*10,random.random()*10
                send=SpawnRequest(x,y,0,w)
                create(send)
        # for command
        for cmd in command_wait_list:
            h=handlers[cmd[0]]
            if cmd[1]==False:
                h.vel=0
                h.ang=0
            else:
                h.vel=cmd[2]
                h.ang=cmd[3]
        # refresh
        wait_list=list()
        poses=list()
        command_wait_list=list()

        for handler in handlers.values():
            vel_msg = Twist()
            vel_msg.linear.x=handler.vel
            vel_msg.angular.z=handler.ang
            handler.publisher.publish(vel_msg)
            # rospy.loginfo("publish turtle velocity command[%s %0.2f m/s, %0.2f rad/s]",\
            #     handler.name,vel_msg.linear.x,vel_msg.angular.z)
        
        rate.sleep()
    # s=rospy.Service('turtle_create_client',StuScore,createCallback)

    # print ("Ready to print hello string")
    # rospy.spin()

if __name__=="__main__":
    handlers=dict()
    poses=list()
    wait_list=list()
    command_wait_list=list()
    turtle_command_server()