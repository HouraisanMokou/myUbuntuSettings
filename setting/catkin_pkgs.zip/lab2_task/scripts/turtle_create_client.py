#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
import rospy
from lab2_task.srv import *
import argparse

def turtle_create_client(name='default'):
    rospy.init_node('turtle_create_client')
    rospy.wait_for_service('turtle_create')
    try:
        client = rospy.ServiceProxy('turtle_create',turtle_create)
        response = client(name)
        return response
    except rospy.ServiceException as e:
        print("service call failed: %s"%e)

if __name__=="__main__":
    # parser=argparse.ArgumentParser("create_client")
    # parser.add_argument("--name",default="default",type=str,help="the name of new turtle")
    # args,unkowwn=parser.parse_known_args()
    # print("Response : %s"%(turtle_create_client('you')))
    import sys
    print("Response : %s"%(turtle_create_client(sys.argv[1])))