#!/usr/bin/env python

import rospy,tf,math,geometry_msgs.msg,turtlesim.srv

if __name__=="__main__":
    rospy.init_node('tf_listener')
    listener=tf.TransformListener()

    rate=rospy.Rate(10.0)
    while not rospy.is_shutdown():
        try:
            (trans,rot)=listener.lookupTransform('base_link','base_laser',rospy.Time(0))
        except (tf.LookupException,tf.ConnectivityException,tf.ExtrapolationException) as e:
            continue

        pose_x=trans[0]+0.1
        pose_y=trans[1]
        pose_z=trans[2]+0.2
        pose=(pose_x,pose_y,pose_z)

        rospy.loginfo(f"[link pose: {pose}]")

        rate.sleep()

